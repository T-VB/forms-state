import React, { useState } from "react";

// set key:value pairs of Form through use of props and initial value of state to an empty string
const Form = (props) => {
  const [firstname, setFirstname] = useState("");
  const [firstnameError, setFirstnameError] = useState("");
  const [lastname, setLastname] = useState("");
  const [lastnameError, setLastnameError] = useState("");
  const [email, setEmail] = useState("");
  const [emailError, setEmailError] = useState("");
  const [password, setPassword] = useState("");
  const [passwordError, setpasswordError] = useState("");
  const [confirmpassword, setConfirmpassword] = useState("");
  const [confirmpasswordError, setConfirmpasswordError] = useState("");

  const firstNameValidation = (e) => {
    //**FirstName validation */
    setFirstname(e.target.value);
    //if statement to validate input: If length of target object value is less than 1, render this, else if ""... else return empty string
    if (e.target.value.length === 0) {
      console.log(e.target.length);
      setFirstnameError("First Name is required!");
    } else if (e.target.value.length < 3) {
      setFirstnameError("First Name must be 3 characters or longer!");
    } else {
      //'falsy' value = empty string
      setFirstnameError("");
    }
  };

  //e = event object
  const createUser = (e) => {
    //(**Standard - e.preventDefault();) prevent default refresh to prevent state reset/refresh
    e.preventDefault();

    //**LastName validation */
    setLastname(e.target.value);
    //if statement to validate input: If length of target object value is less than 1, render this, else if ""... else return empty string
    if (e.target.value.length === 0) {
      setLastnameError("Last Name is required!");
    } else if (e.target.value < 2) {
      setLastnameError("Last Name must be 2 characters or longer!");
    } else {
      //'falsy' value = empty string
      setLastnameError("");
    }

    //**Email validation */
    setEmail(e.target.value);
    //if statement to validate input: If length of target object value is less than 1, render this, else if ""... else return empty string
    if (e.target.value.length === 0) {
      setEmailError("Email is required!");
    } else if (e.target.value < 5) {
      setEmailError("Email must be 5 characters or longer!");
    } else {
      //'falsy' value = empty string
      setEmailError("");
    }

    //**Password validation */
    setPassword(e.target.value);
    //if statement to validate input: If length of target object value is less than 1, render this, else if ""... else return empty string
    if (e.target.value.length === 0) {
      setpasswordError("Password is required!");
    } else if (e.target.value < 5) {
      setpasswordError("Email must be 5 characters or longer!");
    } else {
      //'falsy' value = empty string
      setpasswordError("");
    }

    //**Email validation */
    setConfirmpassword(e.target.value);
    //if statement to validate input: If length of target object value is less than 1, render this, else if ""... else return empty string
    if (e.target.value.length === 0) {
      setConfirmpasswordError("passwords must match!");
    } else if (e.target.value < 5) {
      setConfirmpasswordError("passwords must match");
    } else {
      //'falsy' value = empty string
      setConfirmpasswordError("");
    }

    //es6 shorthand syntax for building/creating an object
    const newUser = { firstname, lastname, email, password, confirmpassword };
    console.log("Welcome", newUser);
    //setters here for properties of a newUser:
    setFirstname("");
    setLastname("");
    setEmail("");
    setPassword("");
    setConfirmpassword("");
  };
  return (
    //insert onSubmit form for a user to input info to createUser
    <div style={{ textAlign: "center" }}>
      <form onSubmit={createUser}>
        <div>
          <label>First Name: </label>
          <input type="text" value={firstname} onChange={firstNameValidation} />
          <div>{firstnameError ? <p> {firstnameError}</p> : ""}</div>
        </div>

        <div>
          <label>Last Name:</label>
          <input
            type="text"
            //value={lastname}
            onChange={(e) => setLastname(e.target.value)}
            //onChange={createUser}
          />
          {lastnameError ? <p>{lastnameError}</p> : ""}
        </div>

        <div>
          <label>Email:</label>
          <input
            type="text"
            //value={email}
            onChange={(e) => setEmail(e.target.value)}
            //onChange={createUser}
          />
          {emailError ? <p> {emailError}</p> : ""}
        </div>

        <div>
          <label>Password:</label>
          <input
            type="password"
            //value={password}
            onChange={(e) => setPassword(e.target.value)}
            //onChange={createUser}
          />
          {passwordError ? <p> {passwordError}</p> : ""}
        </div>

        <div>
          <label>Confirm Password:</label>
          <input
            type="password"
            //value={confirmpassword}
            onChange={(e) => setConfirmpassword(e.target.value)}
            //onChange={createUser}
          />
          {confirmpasswordError ? <p> {confirmpasswordError}</p> : ""}
        </div>

        {firstnameError ? (
          <input type="submit" value="Submit" disabled />
        ) : (
          <input type="submit" value="Submit" />
        )}

        <input type="submit" value="Create User" />
        <button className="btn btn-primary mt-3">Submit</button>
      </form>

      <div>
        <h3 style={{ textAlign: "center" }}>Your Form Data</h3>
        <p>
          <label>First Name: </label>
          {firstname}
        </p>
        <p>
          <label>Last Name: </label>
          {lastname}
        </p>
        <p>
          <label>Email: </label>
          {email}
        </p>
        <p>
          <label>Password: </label>
          {password}
        </p>
        <p>
          <label>Confirm Password: </label>
          {confirmpassword}
        </p>
      </div>
    </div>
  );
};

export default Form;
